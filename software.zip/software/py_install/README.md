
## Installation Steps (安装步骤)

unzip py_install_Vx.x.x.zip

cd py_install

sudo python3 setup.py install

