import serial
import struct
import time
import rospy
from geometry_msgs.msg import Twist

def double_to_bytes(f):
    return struct.pack('<d', f) # the '<' indicates little-endian

def send_packets(ser, cmd_vel):
    # handling linear.x packet
    linear_x_bytes = double_to_bytes(cmd_vel.linear.x)
    linear_x_packet = bytearray(b'\x57\x51') # WQ (0x57, 0x51) denotes linear.x packet
    linear_x_packet.extend(linear_x_bytes)
    # print(linear_x_packet)
    ser.write(linear_x_packet)
    time.sleep(1)

    # handling linear.y packet
    linear_y_bytes = double_to_bytes(cmd_vel.linear.y)
    linear_y_packet = bytearray(b'\x57\x52') # WR (0x57, 0x52) denotes linear.y packet
    linear_y_packet.extend(linear_y_bytes)
    # print(linear_y_packet)
    ser.write(linear_y_packet)
    time.sleep(1)

    # handling linear.z packet
    linear_z_bytes = double_to_bytes(cmd_vel.linear.z)
    linear_z_packet = bytearray(b'\x57\x53') # WS (0x57, 0x53) denotes linear.z packet
    linear_z_packet.extend(linear_z_bytes)
    # print(linear_z_packet)
    ser.write(linear_z_packet)
    time.sleep(1)

    # handling angular.x packet
    angular_x_bytes = double_to_bytes(cmd_vel.angular.x)
    angular_x_packet = bytearray(b'\x57\x54') # WT (0x57, 0x54) denotes linear.x packet
    angular_x_packet.extend(angular_x_bytes)
    # print(angular_x_packet)
    ser.write(angular_x_packet)
    time.sleep(1)

    # handling angular.y packet
    angular_y_bytes = double_to_bytes(cmd_vel.angular.y)
    angular_y_packet = bytearray(b'\x57\x55') # WU (0x57, 0x55) denotes linear.x packet
    angular_y_packet.extend(angular_y_bytes)
    # print(angular_y_packet)
    ser.write(angular_y_packet)
    time.sleep(1)

    # handling angular.z packet
    angular_z_bytes = double_to_bytes(cmd_vel.angular.z)
    angular_z_packet = bytearray(b'\x57\x56') # WV (0x57, 0x56) denotes linear.x packet
    angular_z_packet.extend(angular_z_bytes)
    # print(angular_z_packet)
    ser.write(angular_z_packet)
    time.sleep(1)

if __name__ == '__main__':
    msg = Twist() # create a blanck Twist message
    msg.linear.x = 132.5632463245
    msg.linear.y = 3.27546538
    msg.linear.z = 0.0023503
    msg.angular.x = -0.063422
    msg.angular.y = -21343.2
    msg.angular.z = 32.221200006
    
    ser1 = serial.Serial("/dev/ttyAMA0", 115200) # init uart port
    send_packets(ser1, msg)

