#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist

def turnin_circle():
    pub = rospy.Publisher('cmd_vel', Twist, queue_size=10)
    rospy.init_node('turnin_circle', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    while not rospy.is_shutdown():
        now = int(rospy.get_time())
        
        cmd = Twist()
        cmd.linear.x = now % 5
        cmd.angular.x = now % 5
        print(cmd)
        
        pub.publish(cmd)    
        rate.sleep()

def move_unit_forward():
    pub = rospy.Publisher('cmd_vel', Twist, queue_size=10)
    rospy.init_node('move_unit_forward', anonymous=True)
    rate = rospy.Rate(1) # 1hz
    while not rospy.is_shutdown():
        
        cmd = Twist()
        cmd.linear.x = 1.0
        print(cmd)
        
        pub.publish(cmd)
        rate.sleep()

def stop():
    pub = rospy.Publisher('cmd_vel', Twist, queue_size=10)
    rospy.init_node('stop', anonymous=True)
    cmd = Twist()
    pub.publish(cmd)

if __name__ == '__main__':
    try:
        move_unit_forward()
    except rospy.ROSInterruptException:
        stop()
        pass
        
