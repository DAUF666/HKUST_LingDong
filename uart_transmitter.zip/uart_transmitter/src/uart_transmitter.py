#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist, Pose, TransformStamped
import time
import numpy as np
import math
import serial
import struct

def double_to_bytes(f):
    return struct.pack('<d', f) # the '<' indicates little-endian

def send_packets(cmd_vel):
    # handling linear.x packet
    linear_x_bytes = double_to_bytes(cmd_vel.linear.x)
    linear_x_packet = bytearray(b'\x57\x51') # WQ (0x57, 0x51) denotes linear.x packet
    linear_x_packet.extend(linear_x_bytes)
    # print(linear_x_packet)
    ser.write(linear_x_packet)

    # handling linear.y packet
    linear_y_bytes = double_to_bytes(cmd_vel.linear.y)
    linear_y_packet = bytearray(b'\x57\x52') # WR (0x57, 0x52) denotes linear.y packet
    linear_y_packet.extend(linear_y_bytes)
    # print(linear_y_packet)
    ser.write(linear_y_packet)

    # handling linear.z packet
    linear_z_bytes = double_to_bytes(cmd_vel.linear.z)
    linear_z_packet = bytearray(b'\x57\x53') # WS (0x57, 0x53) denotes linear.z packet
    linear_z_packet.extend(linear_z_bytes)
    # print(linear_z_packet)
    ser.write(linear_z_packet)

    # handling angular.x packet
    angular_x_bytes = double_to_bytes(cmd_vel.angular.x)
    angular_x_packet = bytearray(b'\x57\x54') # WT (0x57, 0x54) denotes linear.x packet
    angular_x_packet.extend(angular_x_bytes)
    # print(angular_x_packet)
    ser.write(angular_x_packet)

    # handling angular.y packet
    angular_y_bytes = double_to_bytes(cmd_vel.angular.y)
    angular_y_packet = bytearray(b'\x57\x55') # WU (0x57, 0x55) denotes linear.x packet
    angular_y_packet.extend(angular_y_bytes)
    # print(angular_y_packet)
    ser.write(angular_y_packet)

    # handling angular.z packet
    angular_z_bytes = double_to_bytes(cmd_vel.angular.z)
    angular_z_packet = bytearray(b'\x57\x56') # WV (0x57, 0x56) denotes linear.x packet
    angular_z_packet.extend(angular_z_bytes)
    # print(angular_z_packet)
    ser.write(angular_z_packet)

if __name__ == '__main__':
    rospy.init_node('uart_transmitter', anonymous=False)
    cmd_vel_subscriber = rospy.Subscriber("/cmd_vel", Twist, send_packets)
    
    ser = serial.Serial("/dev/ttyAMA0", 115200) # init uart port
    
    # rate = rospy.Rate(50)
    # while not rospy.is_shutdown():
    #     rate.sleep()
        
    rospy.spin()

