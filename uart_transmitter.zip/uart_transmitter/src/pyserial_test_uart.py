import serial

if __name__ == '__main__':
    ser = serial.Serial("/dev/ttyAMA0", 115200)
    for i in range(5):
        words = "Hello\n"
        print(words)
        ser.write(bytes(words, 'utf-8'))

