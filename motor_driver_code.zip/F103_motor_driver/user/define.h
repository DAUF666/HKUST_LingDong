#ifndef _DEFINE_H
#define _DEFINE_H

// This is the motor id of the current motor
#define THIS_MOTOR MOTOR_4
extern u8 this_motor;

#define PWM_POLARITY TIM_OCPolarity_High

#define ENCODER_INPUT_MODE GPIO_Mode_IN_FLOATING

#define ENCODER_RESOLUTION 1024

#if ENCODER_RESOLUTION==512 
	#define ENCODER_PRESCALER 1
#elif ENCODER_RESOLUTION==1024
	//Else is 1024
	#define ENCODER_PRESCALER 2
#else
	#error Encoder resolution not exist
#endif

#define CONTROL_FREQ 512
	
//Direction: 1 or -1
#define PWM_DIR (1)
#define ENC_DIR (1)

#define MAX_ORIG_VEL (6000) //(150000)
#define MAX_ORIG_ACC (20000) //(900000)

#define MALF_FLASH_FREQ 42
#define NORM_FLASH_FREQ 256

#endif
