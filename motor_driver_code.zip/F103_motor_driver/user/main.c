#include "stm32f10x.h"
#include "ticks.h"
#include "define.h"
#include "led.h"
#include "control.h"
#include "debug.h"

static u32 last_ticks = (u32)-1;

int main(){

	ticks_init();
	can_init();
	can_rx_init();
	can_motor_init();
	motor_init();
	encoder_init();
	uart_init(COM1, 115200);
	led_init();
	
	#ifndef DEBUG_MODE
		config_debug_pin();
	#endif
	
	//Wait for some time to denoise
	while(get_ticks() <  1 + this_motor * 2){
		__asm__("nop");
	}
	
	control_init();
	
	#ifdef DEBUG_MODE
		enter_debug_mode();
	#else
		detect_debug_pin();
	#endif
	
	while(1){
		u32 this_ticks = get_ticks();
		if (this_ticks != last_ticks){
			
			static u32 last_encoder_ticks = 0;
			if (this_ticks - last_encoder_ticks >= 4){
				static bool enc_last_state = false;
				bool enc_this_state = encoder_malfunction();
				
				//Handle encoder malfunction and recovery signal
				if (enc_this_state && !enc_last_state){
					//If encoder state change from working to not working
					life_signal_freq = MALF_FLASH_FREQ;
					
				}else if (enc_last_state && !enc_this_state){
					//If encoder state change from not working to working
					life_signal_freq = NORM_FLASH_FREQ;
				}

				
				enc_last_state = enc_this_state;
				last_encoder_ticks = this_ticks;
			}
			
			static u32 last_uart_ticks = 0;
			if (this_ticks - last_uart_ticks >= 32){
				if (is_debugging()){
					debug_loop();
//					debug_loop2();
				}
				last_uart_ticks = this_ticks;
			}
			
			static u32 last_life_ticks = 0;
			if (!is_debugging() && (this_ticks - last_life_ticks >= life_signal_freq)){
				
				//LED Life signal
				led_blink(LED_2);
				
				last_life_ticks = this_ticks;
			}
			
			//ON -> Command received in last 512 ms via CAN
			if (last_recv_ticks == 0 || ((this_ticks - last_recv_ticks) > 512)){
				led_control(LED_1, Bit_RESET);
			}else{
				led_control(LED_1, Bit_SET);
			}
			
			last_ticks = this_ticks;
		}
	}
}
