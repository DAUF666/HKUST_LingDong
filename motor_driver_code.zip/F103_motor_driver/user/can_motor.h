#ifndef _CAN_MOTOR_H
#define _CAN_MOTOR_H

#include "can_protocol.h"
#include "define.h"

#define get_command_id(motor_id)	(CAN_MOTOR_COMMAND_BASE + (uint8_t)motor_id)
#define get_feedback_id(motor_id)	(CAN_MOTOR_FEEDBACK_BASE + (uint8_t)motor_id)

extern volatile u32 last_recv_ticks;

#define CAN_MOTOR_COUNT								16

#define	CAN_MOTOR_COMMAND_BASE				0x0D0
#define	CAN_MOTOR_FEEDBACK_BASE				0x0E0

/*** TX ***/
#define	CAN_MOTOR_VEL_LENGTH					6
#define CAN_MOTOR_VEL_CMD							0xAA

#define CAN_MOTOR_POS_LENGTH 					5
#define CAN_MOTOR_POS_CMD 						0xBC

#define CAN_MOTOR_ACCEL_LENGTH				5
#define CAN_MOTOR_ACCEL_CMD						0x45

#define CAN_MOTOR_MAXV_LENGTH					5
#define CAN_MOTOR_MAXV_CMD						0x49

#define CAN_MOTOR_LOCK_LENGTH	 		  	1
#define CAN_MOTOR_LOCK_CMD						0xEE

typedef enum {
	MOTOR_1 = 0,
	MOTOR_2,
	MOTOR_3,
	MOTOR_4,
	MOTOR_5,
	MOTOR_6,
	MOTOR_7,
	MOTOR_8,
	MOTOR_9,
	MOTOR_10,
	MOTOR_11,
	MOTOR_12,
	MOTOR_13,
	MOTOR_14,
	MOTOR_15,
	MOTOR_16
} MotorID;

typedef enum{
	OPEN_LOOP = 0,
	CLOSE_LOOP = 1
} CloseLoopFlag;

void can_motor_init(void);

#endif
