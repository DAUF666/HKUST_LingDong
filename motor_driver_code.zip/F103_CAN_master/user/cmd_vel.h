#ifndef _CMD_VEL_H
#define _CMD_VEL_H

#include "uart.h"
#include "ticks.h"
#include "master_can_motor.h"

#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#define RPI_UART	COM1

extern double linear_x, linear_y, linear_z, angular_x, angular_y, angular_z;

void cmd_vel_init(void);
void decode_cmd_vel_data(void);
void can_move_vector(float v_x, float v_y, float ang_vel);
void cmd_vel_update(void);

#endif
