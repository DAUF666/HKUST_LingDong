#include "stm32f10x.h"
#include "ticks.h"
#include "define.h"
#include "led.h"
#include "cmd_vel.h"

static u32 last_ticks = (u32)-1;

int main(){

	ticks_init();
	can_init();
	can_rx_init();
	can_motor_init();
	led_init();
	cmd_vel_init(); // init the uart port to receive cmd_vel commands
	
	while(1){
		u32 this_ticks = get_ticks();
		if (this_ticks != last_ticks){
			
			static u32 last_motor_ticks = 0;
			if (this_ticks - last_motor_ticks >= 10)
			{
				cmd_vel_update();
			}
			
			static u32 last_life_ticks = 0;
			if (this_ticks - last_life_ticks >= life_signal_freq){

				led_blink(LED_2);
				
				last_life_ticks = this_ticks;
			}
			
			last_ticks = this_ticks;
		}
	}
}
