#include "master_can_motor.h"
#include "ticks.h"

#define get_command_id(motor_id)	(CAN_MOTOR_COMMAND_BASE + (uint8_t)motor_id)

static void handler(CanRxMsg* msg) {
	return;
}

//Init CAN Motor
void can_motor_init(){
	can_rx_add_filter(CAN_MOTOR_FEEDBACK_BASE, CAN_RX_MASK_DIGIT_0_F, handler);
}

void can_motor_set_vel(MotorID id, int32_t vel, CloseLoopFlag loop){
	CanMessage msg;

	msg.id = get_command_id(id);
	msg.length = CAN_MOTOR_VEL_LENGTH;
	msg.data[0] = CAN_MOTOR_VEL_CMD;
	msg.data[1] = vel;
	msg.data[2] = vel >> 8;
	msg.data[3] = vel >> 16;
	msg.data[4] = vel >> 24;
	msg.data[5] = loop;
	
	can_tx_enqueue(msg);
}

void can_motor_set_pos(MotorID id, int32_t pos){
	CanMessage msg;
	
	msg.id = get_command_id(id);
	msg.length = CAN_MOTOR_POS_LENGTH;
	msg.data[0] = CAN_MOTOR_POS_CMD;

	msg.data[1] = pos;
	msg.data[2] = pos >> 8;
	msg.data[3] = pos >> 16;
	msg.data[4] = pos >> 24;
	can_tx_enqueue(msg);
}

void can_motor_set_accel(MotorID id, uint32_t accel){
	CanMessage msg;
	
	msg.id = get_command_id(id);
	msg.length = CAN_MOTOR_ACCEL_LENGTH;
	msg.data[0] = CAN_MOTOR_ACCEL_CMD;
	msg.data[1] = accel;
	msg.data[2] = accel >> 8;
	msg.data[3] = accel >> 16;
	msg.data[4] = accel >> 24;

	can_tx_enqueue(msg);
}

void can_motor_set_max_vel(MotorID id, uint32_t vel){
	CanMessage msg;
	
	msg.id = get_command_id(id);
	msg.length = CAN_MOTOR_MAXV_LENGTH;
	msg.data[0] = CAN_MOTOR_MAXV_CMD;
	msg.data[1] = vel;
	msg.data[2] = vel >> 8;
	msg.data[3] = vel >> 16;
	msg.data[4] = vel >> 24;

	can_tx_enqueue(msg);
}

void can_motor_lock(MotorID id){
	CanMessage msg;
	
	msg.id = get_command_id(id);
	msg.length = CAN_MOTOR_LOCK_LENGTH;
	msg.data[0] = CAN_MOTOR_LOCK_CMD;
	
	can_tx_enqueue(msg);
}

#undef get_id
