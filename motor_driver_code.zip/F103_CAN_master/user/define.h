#ifndef _DEFINE_H
#define _DEFINE_H

#define PWM_POLARITY TIM_OCPolarity_High

#define ENCODER_INPUT_MODE GPIO_Mode_IN_FLOATING

#define ENCODER_RESOLUTION 1024

#if ENCODER_RESOLUTION==512 
	#define ENCODER_PRESCALER 1
#elif ENCODER_RESOLUTION==1024
	//Else is 1024
	#define ENCODER_PRESCALER 2
#else
	//Other resolution? You are drunk, go home
	#error Hi Today is a good day
#endif

#define CONTROL_FREQ 512
	
//Direction: 1 or -1
#define PWM_DIR (1)
#define ENC_DIR (1)

#define MAX_ORIG_VEL (3000) //(150000)
#define MAX_ORIG_ACC (9000) //(900000)

#define MALF_FLASH_FREQ 42
#define NORM_FLASH_FREQ 256

#endif
