#include "cmd_vel.h"

double linear_x, linear_y, linear_z, angular_x, angular_y, angular_z;
uint8_t buf[10],counter=0,sign=0;

const float LIN_RATIO = 6734.751; // the amount of vel equivalent to moving the car 1 m/s 
const float ANG_RATIO = 6843.69; // the amount of vel equivalent to rotating the car 1 rad/s 
const float HALF_WIDTH = 0.235;
const float HALF_LENGTH = 0.1675;

void cmd_vel_interrupt_handler(uint8_t rx_data)
{
	buf[counter]=rx_data;
	if(counter==0 && buf[0]!=0x57) return;
	counter++;
	if(counter==10){
		counter =0;
		sign=1;
	}

	decode_cmd_vel_data();
//	uart_tx(RPI_UART, &rx_data);
}

void decode_cmd_vel_data(void)
{
	if(sign)
	{
		sign=0;
		if(buf[0]==0x57) 
		{
			switch(buf[1])
			{
				case 0x51:
					memcpy(&linear_x, (uint8_t *) &buf + 2, sizeof(double));
//					uart_tx(RPI_UART, "lx:%f\n", linear_x);
				break;

				case 0x52:
					memcpy(&linear_y, (uint8_t *) &buf + 2, sizeof(double));
//					uart_tx(RPI_UART, "ly:%f\n", linear_y);
				break;
				
				case 0x53:
					memcpy(&linear_z, (uint8_t *) &buf + 2, sizeof(double));
//					uart_tx(RPI_UART, "lz:%f\n", linear_z);
				break;
				
				case 0x54:
					memcpy(&angular_x, (uint8_t *) &buf + 2, sizeof(double));
//					uart_tx(RPI_UART, "ax:%f\n", angular_x);
				break;
				
				case 0x55:
					memcpy(&angular_y, (uint8_t *) &buf + 2, sizeof(double));
//					uart_tx(RPI_UART, "ay:%f\n", angular_y);
				break;
				
				case 0x56:
					memcpy(&angular_z, (uint8_t *) &buf + 2, sizeof(double));
//					uart_tx(RPI_UART, "az:%f\n", angular_z);
				break;
			}
		}
	}
}

void cmd_vel_init(void)
{
	uart_init(RPI_UART, 115200);
	uart_interrupt_init(RPI_UART, cmd_vel_interrupt_handler);
}


void can_move_vector(float v_x, float v_y, float ang_vel){
	can_motor_set_vel(MOTOR_1, (int32_t) -v_x + v_y + (HALF_WIDTH + HALF_LENGTH) * ang_vel, CLOSE_LOOP);
	can_motor_set_vel(MOTOR_2, (int32_t) v_x + v_y + (HALF_WIDTH + HALF_LENGTH) * ang_vel, CLOSE_LOOP);
	can_motor_set_vel(MOTOR_3, (int32_t) -v_x - v_y + (HALF_WIDTH + HALF_LENGTH) * ang_vel, CLOSE_LOOP);
	can_motor_set_vel(MOTOR_4, (int32_t) v_x - v_y + (HALF_WIDTH + HALF_LENGTH) * ang_vel, CLOSE_LOOP);
}

void cmd_vel_update(void){
	const float v_x = linear_x * LIN_RATIO;
	const float v_y = linear_y * LIN_RATIO;
	const float ang_vel = angular_z * ANG_RATIO;
	can_move_vector(v_x, v_y, ang_vel);
}

